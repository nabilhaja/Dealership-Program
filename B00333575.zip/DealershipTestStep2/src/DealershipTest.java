public class DealershipTest {

    public static void main(String[] args) {
        
        Dealership dealership = new Dealership();
        
        String name;
        Comparable make;
        String registration;
        String model;
        String colour;
        String menuOption;
        Integer option;
        do {
            System.out.println("Car Dealership\n");
            System.out.println("0: Quit");
            System.out.println("1: Add a make");
            System.out.println("2: Find a make");
            System.out.println("3: Remove a make");
            System.out.println("4: Display all makes");
            System.out.println("5: Add a car");
            System.out.println("6: Delete a car");
            System.out.println("7: Display cars of specific make");
            System.out.println("8: Display all cars");
            
            menuOption = Input.getString("\n Option: ");
            try {
                option = Integer.valueOf(menuOption);
            } catch (NumberFormatException e) {
                option = -1;
            }
            
            switch (option){
                
                // Quit program
                case 0:
                    System.out.println("Quitting program");
                    break;
                
                // Add a make
                case 1:
                    name = Input.getString("Make: ");
                    if (!"".equals(name)) {
                        dealership.addMake(name);
                    } else {
                        System.out.println("Invalid input - empty field");
                    }
                    break;
                    
                // Find a make
                case 2:
                    name = Input.getString("Make: ");
                    if (!"".equals(name)) {
                        dealership.findMake(name);
                    } else {
                        System.out.println("Invalid input - empty field");
                    }
                    break;
                
                // Remove a make
                case 3:
                    name = Input.getString("Make: ");
                    if (!"".equals(name)) {
                        dealership.removeMake(name);
                    } else {
                        System.out.println("Invalid input - empty field");
                    }
                    break;
                
                // Display all makes
                case 4:
                    dealership.displayMakes();
                    break;
                    
                // Add a car
                case 5:
                    name = Input.getString("Make: ");
                    if (!"".equals(name)) {
                        
                        make = dealership.findMake(name);
                        if (make != null) {
                            
                            registration = Input.getString("Registration: ");
                            model = Input.getString("Model: ");
                            colour = Input.getString("Colour: ");
                            
                            if ((!"".equals(registration)) && (!"".equals(model)) && (!"".equals(colour))) {
                                dealership.addCar(name, registration, model, colour);
                            } else {
                                System.out.println("Invalid input - empty field");
                            }
                        }
                    } else {
                        System.out.println("Invalid input - empty field");
                    }
                    
                    break;
                    
                // Delete a car
                case 6:
                    name = Input.getString("Make: ");
                    if (!"".equals(name)) {
                        
                        make = dealership.findMake(name);
                        if (make != null) {
                            
                            registration = Input.getString("Registration: ");
                            
                            if (!"".equals(registration)) {
                                dealership.deleteCar(name, registration);
                            } else {
                                System.out.println("Invalid input - empty field");
                            }
                        }
                    } else {
                        System.out.println("Invalid input - empty field");
                    }
                    break;
                
                // Display cars of specific make
                case 7:
                    name = Input.getString("Make: ");
                    dealership.displayMakesCars(name);
                    break;
                    
                // Display all cars
                case 8:
                    dealership.displayAllCars();
                    break;
                
                // Invalid option
                default:
                    System.out.println("Invalid menu option");
                    break;
            }
        } while (option != 0);
    }
}
