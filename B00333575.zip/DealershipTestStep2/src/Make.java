public class Make implements Comparable<Make>{
    
    private String name;
    private SortedLinkedListCars cars;
    private Car car;
    
    public Make(String name){
        this.name = name;
        this.cars = new SortedLinkedListCars();
    }
    
    public String getName() {
        return this.name;
    }
    
    public void addCar(String registration, String model, String colour) {
        try {
            car = new Car(registration, model, colour);
            this.cars.insert(car);
            System.out.println("Car has been added");
        } catch (SortedLinkedListCars.NotUniqueException e) {
            System.out.println("Error - registration not unique");
        }
    }
    
    private Car tempCar(String registration) {
        car = new Car(registration, "", "");
        return car;
    }
    
    public void deleteCar(String registration) {
        try {
            car = tempCar(registration);
            this.cars.remove(car);
            System.out.println("Car has been deleted");
        } catch (SortedLinkedListCars.NotFoundException e) {
            System.out.println("Error - car not found");
        }
    }
    
    public void displayCars() {
        System.out.print(this.cars);
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    @Override
    public int compareTo(Make anotherMake) {
        return this.name.compareTo(anotherMake.getName());
    }
    
}
