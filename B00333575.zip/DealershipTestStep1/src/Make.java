public class Make implements Comparable<Make>{
    
    private String name;
    
    public Make(String name){
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    
    
    @Override
    public String toString() {
        return this.name;
    }
    
    @Override
    public int compareTo(Make anotherMake) {
        return this.name.compareTo(anotherMake.getName());
    }
    
}
