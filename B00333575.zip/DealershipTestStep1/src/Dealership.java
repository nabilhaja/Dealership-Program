public class Dealership {

    private SortedLinkedListMakes makes;
    private Make make;

    public Dealership() {
        this.makes = new SortedLinkedListMakes();
    }

    public void addMake(String name) {
        try {
            make = new Make(name);
            makes.insert(make);
            System.out.println("Make has been added");
        } catch (SortedLinkedListMakes.NotUniqueException e) {
            System.out.println("Error - make not unique");
        }
    }

    private Make tempMake(String name) {
        make = new Make(name);
        return make;
    }

    public Comparable findMake(String name) {
        Comparable foundMake = null;
        try {
            make = tempMake(name);
            foundMake = this.makes.find(make);
            System.out.println("Make found");
        } catch (SortedLinkedListMakes.NotFoundException e) {
            System.out.println("Make not found");
        }
        return foundMake;
    }

    public void removeMake(String name) {
        try {
            make = tempMake(name);
            this.makes.remove(make);
            System.out.println("Make has been removed");
        } catch (SortedLinkedListMakes.NotFoundException e) {
            System.out.println("Error - make not found");
        }
    }

    public void displayMakes() {
        System.out.print(this.makes);
    }
}
