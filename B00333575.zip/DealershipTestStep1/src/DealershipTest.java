public class DealershipTest {

    public static void main(String[] args) {
        
        Dealership dealership = new Dealership();
        
        String name;
        Comparable make;
        String registration;
        String model;
        String colour;
        String menuOption;
        Integer option;
        do {
            System.out.println("\nCar Dealership");
            System.out.println("0: Quit");
            System.out.println("1: Add a make");
            System.out.println("2: Find a make");
            System.out.println("3: Remove a make");
            System.out.println("4: Display all makes");
            
            menuOption = Input.getString("\n Option: ");
            try {
                option = Integer.valueOf(menuOption);
            } catch (NumberFormatException e) {
                option = -1;
            }
            
            switch (option){
                
                // Quit program
                case 0:
                    System.out.println("Quitting program");
                    break;
                
                // Add a make
                case 1:
                    name = Input.getString("Make: ");
                    if (!"".equals(name)) {
                        dealership.addMake(name);
                    } else {
                        System.out.println("Invalid input - empty field");
                    }
                    break;
                    
                // Find a make
                case 2:
                    name = Input.getString("Make: ");
                    if (!"".equals(name)) {
                        dealership.findMake(name);
                    } else {
                        System.out.println("Invalid input - empty field");
                    }
                    break;
                
                // Remove a make
                case 3:
                    name = Input.getString("Make: ");
                    if (!"".equals(name)) {
                        dealership.removeMake(name);
                    } else {
                        System.out.println("Invalid input - empty field");
                    }
                    break;
                
                // Display all makes
                case 4:
                    dealership.displayMakes();
                    break;
                    
                // Invalid option
                default:
                    System.out.println("Invalid menu option");
                    break;
            }
        } while (option != 0);
    }
}
